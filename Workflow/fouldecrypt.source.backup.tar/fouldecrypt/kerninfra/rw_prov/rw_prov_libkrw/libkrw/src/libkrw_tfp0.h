#ifndef _LIBKRW_TFP0_H_
#define _LIBKRW_TFP0_H_
#include "libkrw_plugin.h"
int libkrw_initialization(krw_handlers_t handlers);
#endif
